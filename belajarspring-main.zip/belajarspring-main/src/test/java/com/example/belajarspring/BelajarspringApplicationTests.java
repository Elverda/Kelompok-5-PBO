package com.example.belajarspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
